import os 
from django.shortcuts import render
import compute.predict as cp 
from django.http import HttpResponse, JsonResponse
import fan.settings as set

# Create your views here.

def confirmConnection(request):
    return JsonResponse({"status":"successful"})

def predict(request):
    username = request.POST.get('username')
    turbid = int(request.POST.get('turbid'))
    
    outputLen = int(request.POST.get('outputLen'))

    file = request.FILES.get('file')

    with open(os.path.join(set.CSV_UPLOAD,username + '.csv'),'wb') as fout:
        for chunk in file.chunks():
            fout.write(chunk)

    # # print(username)
    # print(type(turbid))
    # print(type(outputLen))
    # # print(turbid)
    # print(outputLen)

    # print(file)
    df = cp.readCSV(os.path.join(set.CSV_UPLOAD,username + '.csv'),turbid)
    js = cp.forecast(df,turbid,outputLen)

    return JsonResponse(js)