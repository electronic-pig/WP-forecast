# 项目运行需要的环境

## 基本包

 Django==4.1.7(运行pip install Django==4.1.7即可，下同)

 numpy==1.19.5

 paddlets==1.1.0 

 pandas==1.3.5

## 额外需求

理论上，安装这些包就足够了，实际上可能还满足以下要求：

1. python版本在3.9以下

2. paddlepaddle

3. ray

4. optuna

5. django-cors-headers

## 如果在启动vue或者django中仍然存在问题，baidu或gpt或者群里问也行



# 项目结构

-django_test：与django后端交互的示例，主要包含axios的使用

     -django_test.html:基于vue的html，因为未使用脚手架，可以直接双击运行,代码内含详细注释

     -vue.js:django_test所依赖的vue

-backend：初步完成的django后端

      -fan：整个项目

          -manage.py:程序入口文件



# 启动django_test.html

双击django_test.html文件，并在浏览器打开控制台（ctrl + shift + i）

此时可以点击“点我测试服务器是否连通”，因为未启动django后端故显示未成功建立

![6e5fe42d-f197-4ab2-88c8-04994ea39aac](file:///C:/Users/Lenovo/Pictures/Typedown/6e5fe42d-f197-4ab2-88c8-04994ea39aac.png)



# 启动django项目

在命令行或者编辑器切换到manage.py同级目录下，然后运行

python manage.py runserver localhost:8001

此代表表示在本机的8001端口运行django项目，当然‘locahost’换成‘127.0.0.1’也行；若想终止项目在控制台按下‘ctrl + c’即可

运行成功如下：

![02f49c0a-554e-4712-a7f3-ad4a4f6db64a](file:///C:/Users/Lenovo/Pictures/Typedown/02f49c0a-554e-4712-a7f3-ad4a4f6db64a.png)



# 前后端交互

## 连接建立测试

此时回到刚刚打开的html再进行连接测试，会显示连接建立成功，如下：

![077ddf25-a380-4532-802d-773026a43461](file:///C:/Users/Lenovo/Pictures/Typedown/077ddf25-a380-4532-802d-773026a43461.png)

## 尝试上传文件进行预测

上传csv文件后，等待一段时间，出现下面结果即表示正确

![44df74f6-ef73-445f-b418-6293111900bb](file:///C:/Users/Lenovo/Pictures/Typedown/44df74f6-ef73-445f-b418-6293111900bb.png)

![e091f704-a36b-4acd-8c87-d6fa989259da](file:///C:/Users/Lenovo/Pictures/Typedown/e091f704-a36b-4acd-8c87-d6fa989259da.png)



# 后端处理的大致逻辑

1. 接收前端的文件(csv),username(用户名),turbid(风机号，注意需要是[11,20]的整数),outputLen(预测长度，非负整数)

2. 储存接收的文件，文件名为{{username}}.csv

3. 读取csv文件到内存

4. 数据预处理，并预测，将预测结果转换成json字符串

5. 返回jsonResponse

# TODO(这部分前端注释有，此处再次列出)

1. 让用户输入风机号（建立列表选择），预测长度

2. 用户名主要是用来处理多个请求（每个请求需要先将文件储存，用户名不同能避免文件名不会覆盖）

3. 为了加快速度，csv文件可以仅仅传输最后672个数据

4. 利用json数据进行页面渲染或提供下载  


